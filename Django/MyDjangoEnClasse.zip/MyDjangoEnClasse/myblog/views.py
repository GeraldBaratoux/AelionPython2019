from django.shortcuts import render, get_object_or_404, HttpResponse
from django.utils import timezone
from .models import Post
from django.core.mail import send_mail
from django.conf import settings

from pylab import *
from io import BytesIO
import base64

# Create your views here.

def post_list(request):
    posts = Post.objects.filter(published_date__lte=timezone.now()).order_by('published_date')
    return render(request, 'myblog/post_list.html', {'posts': posts})

def post_detail(request, pk):
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'myblog/post_detail.html', {'post': post})


def courbe(request):
    print(randint(10))
    fig = Figure()
    ax = fig.add_subplot(111)
    x = []
    y = []
    now = datetime.datetime.now()
    delta = datetime.timedelta(days=1)
    for i in range(10):
        x.append(now)
        now += delta
        y.append(randint(0, 1000))
    ax.plot_date(x, y, '-')
    ax.xaxis.set_major_formatter(DateFormatter('%Y-%m-%d'))
    fig.autofmt_xdate()

    buf = BytesIO()
    fig.savefig(buf, format='png', dpi=300)
    image_base64 = base64.b64encode(buf.getvalue()).decode('utf-8').replace('\n', '')
    buf.close()

    return render(request, 'myblog/courbe.html', {'image_base64': image_base64})

def contact(request):
    if request.method == 'POST':
        message = request.POST['message']
        send_mail('Contact Form',
                  message,
                  settings.EMAIL_HOST_USER,
                  ['geraldbaratoux@gmail.com'],
                  fail_silently=True)
        return HttpResponse("message envoyé")
    else:
        return render(request, 'myblog/contact.html')